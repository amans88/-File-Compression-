document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const fileInput = document.getElementById('fileInput');
    const compressBtn = document.getElementById('compressBtn');
    const fileNameDisplay = document.getElementById('fileName');
    const progressContainer = document.getElementById('progressContainer');
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    const progressPercent = document.getElementById('progressPercent');
    const resultsCard = document.getElementById('resultsCard');
    const downloadContainer = document.getElementById('downloadContainer');
    const downloadLink = document.getElementById('downloadLink');
    
    // File selection handler
    fileInput.addEventListener('change', function(e) {
        if (e.target.files.length > 0) {
            const file = e.target.files[0];
            fileNameDisplay.textContent = file.name;
            fileNameDisplay.classList.remove('text-muted');
            fileNameDisplay.classList.add('text-primary');
            compressBtn.disabled = false;
            
            // Reset UI for new file
            progressContainer.style.display = 'none';
            resultsCard.style.display = 'none';
            downloadContainer.style.display = 'none';
        } else {
            fileNameDisplay.textContent = "No file selected";
            fileNameDisplay.classList.remove('text-primary');
            fileNameDisplay.classList.add('text-muted');
            compressBtn.disabled = true;
        }
    });
    
    // Compress button handler
    compressBtn.addEventListener('click', async function() {
        if (!fileInput.files[0]) {
            showError("Please select a file first!");
            return;
        }
        
        await compressAndDownload(fileInput.files[0]);
    });
    
    async function compressAndDownload(file) {
        const formData = new FormData();
        formData.append('file', file);
        
        try {
            // Show initial progress
            progressContainer.style.display = 'block';
            progressText.textContent = `Preparing ${file.name}...`;
            progressBar.style.width = '5%';
            progressPercent.textContent = '5%';
            progressBar.classList.remove('bg-danger');
            progressBar.classList.add('bg-primary');

            // Initial progress simulation (5-25%)
            for (let i = 5; i <= 25; i += 5) {
                await new Promise(resolve => setTimeout(resolve, 100));
                updateProgress(i, `Analyzing file... (${i}%)`);
            }

            // Send to backend with timeout
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 30000); // 30s timeout
            
            updateProgress(30, "Uploading to server...");
            
            const response = await fetch('http://localhost:3000/compress', {
                method: 'POST',
                body: formData,
                signal: controller.signal
            });
            
            clearTimeout(timeout);
            
            // Check for HTTP errors
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.error || `Server error: ${response.status}`);
            }

            const result = await response.json();
            
            // Final progress animation (60-100%)
            for (let i = 60; i <= 100; i += 10) {
                await new Promise(resolve => setTimeout(resolve, 150));
                updateProgress(i, `Finalizing... (${i}%)`);
            }

            // Update results
            document.getElementById('originalSize').textContent = formatBytes(result.originalSize);
            document.getElementById('compressedSize').textContent = formatBytes(result.compressedSize);
            document.getElementById('compressionRatio').textContent = `${result.ratio}% smaller`;
            document.getElementById('timeTaken').textContent = result.timeTaken ? `${result.timeTaken}s` : "1.25s";

            // Setup download
            downloadLink.href = `http://localhost:3000/download?file=${result.filename}`;
            downloadLink.setAttribute('download', result.filename);
            downloadLink.textContent = `Download ${result.filename}`;
            downloadContainer.style.display = 'block';
            
            updateProgress(100, 'Compression complete!');
            resultsCard.style.display = 'block';

        } catch (error) {
            console.error('Compression error:', error);
            showError(error.message);
        }
    }
    
    function updateProgress(percent, message) {
        progressBar.style.width = `${percent}%`;
        progressPercent.textContent = `${percent}%`;
        progressText.textContent = message;
    }
    
    function showError(message) {
        progressText.textContent = `Error: ${message}`;
        progressBar.classList.remove('bg-primary');
        progressBar.classList.add('bg-danger');
        alert(`Error: ${message}\nCheck console for details`);
    }
    
    function formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(decimals)) + ' ' + sizes[i];
    }
});