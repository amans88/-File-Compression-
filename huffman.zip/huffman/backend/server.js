const express = require('express');
const fileUpload = require('express-fileupload');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const huffman = require('./huffman');

const app = express();

// Configuration
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const UPLOADS_DIR = path.join(__dirname, 'uploads');

// Middleware
app.use(cors());
app.use(fileUpload({
    limits: { fileSize: MAX_FILE_SIZE },
    abortOnLimit: true
}));
app.use(express.static(path.join(__dirname, '../frontend')));

// Ensure uploads directory exists
if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR);
}

// Compression endpoint
app.post('/compress', async (req, res) => {
    const startTime = Date.now();
    
    try {
        // Validate file
        if (!req.files?.file) {
            return res.status(400).json({ 
                error: 'No file uploaded',
                details: 'Please select a file to compress'
            });
        }

        const file = req.files.file;
        console.log(`Processing: ${file.name} (${formatBytes(file.size)})`);

        // Validate file size
        if (file.size > MAX_FILE_SIZE) {
            return res.status(413).json({
                error: 'File too large',
                details: `Max size is ${formatBytes(MAX_FILE_SIZE)}`
            });
        }

        // Prepare paths
        const inputPath = path.join(UPLOADS_DIR, file.name);
        const outputFilename = `compressed_${Date.now()}_${file.name}.huff`;
        const outputPath = path.join(UPLOADS_DIR, outputFilename);

        // Save uploaded file
        await file.mv(inputPath);
        console.log(`Saved to: ${inputPath}`);

        // Compress
        console.log('Starting compression...');
        const compressor = new huffman.HuffmanCompressor();
        await compressor.compress(inputPath, outputPath);
        
        // Get results
        const originalSize = fs.statSync(inputPath).size;
        const compressedSize = fs.statSync(outputPath).size;
        const ratio = ((1 - (compressedSize / originalSize)) * 100).toFixed(2);
        const timeTaken = ((Date.now() - startTime) / 1000).toFixed(2);

        console.log(`Compressed to: ${outputPath} (${ratio}% reduction)`);
        console.log(`Time taken: ${timeTaken}s`);

        // Clean up input file
        fs.unlinkSync(inputPath);

        res.json({
            success: true,
            filename: outputFilename,
            originalSize,
            compressedSize,
            ratio,
            timeTaken
        });

    } catch (error) {
        console.error('Compression error:', error);
        res.status(500).json({
            error: 'Compression failed',
            details: error.message,
            stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
        });
    }
});

// Download endpoint
app.get('/download', (req, res) => {
    try {
        const filename = req.query.file;
        if (!filename) {
            return res.status(400).send('Filename is required');
        }

        const filePath = path.join(UPLOADS_DIR, filename);
        if (!fs.existsSync(filePath)) {
            return res.status(404).send('File not found');
        }

        res.download(filePath, filename, (err) => {
            if (err) {
                console.error('Download failed:', err);
                if (!res.headersSent) {
                    res.status(500).send('Download failed');
                }
            } else {
                // Delete file after download completes
                setTimeout(() => {
                    try {
                        fs.unlinkSync(filePath);
                        console.log(`Cleaned up: ${filename}`);
                    } catch (cleanupError) {
                        console.error('Cleanup failed:', cleanupError);
                    }
                }, 5000);
            }
        });
    } catch (error) {
        console.error('Download error:', error);
        res.status(500).send('Server error');
    }
});

// Helper function
function formatBytes(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2) + ' ' + sizes[i]);
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Upload limit: ${formatBytes(MAX_FILE_SIZE)}`);
});