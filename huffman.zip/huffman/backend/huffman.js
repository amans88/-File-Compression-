const fs = require('fs');
const path = require('path');

class HuffmanNode {
    constructor(char, freq) {
        this.char = char;
        this.freq = freq;
        this.left = null;
        this.right = null;
    }
}

class HuffmanCompressor {
    constructor() {
        this.codes = {};
    }

    buildFrequencyDict(text) {
        const frequency = {};
        for (const char of text) {
            frequency[char] = (frequency[char] || 0) + 1;
        }
        return frequency;
    }

    buildHuffmanTree(frequency) {
        const nodes = Object.entries(frequency).map(
            ([char, freq]) => new HuffmanNode(char, freq)
        );
        
        while (nodes.length > 1) {
            nodes.sort((a, b) => a.freq - b.freq);
            const left = nodes.shift();
            const right = nodes.shift();
            const merged = new HuffmanNode(null, left.freq + right.freq);
            merged.left = left;
            merged.right = right;
            nodes.push(merged);
        }

        return nodes[0];
    }

    generateCodes(node, path = '') {
        if (node.char) {
            this.codes[node.char] = path;
            return;
        }
        this.generateCodes(node.left, path + '0');
        this.generateCodes(node.right, path + '1');
    }

    async compress(inputPath, outputPath) {
        return new Promise((resolve, reject) => {
            try {
                const text = fs.readFileSync(inputPath, 'utf8');
                const frequency = this.buildFrequencyDict(text);
                const tree = this.buildHuffmanTree(frequency);
                this.generateCodes(tree);

                let encodedText = '';
                for (const char of text) {
                    encodedText += this.codes[char];
                }

                // Pad the encoded text to make it divisible by 8
                const padding = 8 - (encodedText.length % 8);
                const paddedText = encodedText + '0'.repeat(padding);
                
                // Convert binary string to buffer
                const buffer = Buffer.alloc(Math.ceil(paddedText.length / 8));
                for (let i = 0; i < paddedText.length; i += 8) {
                    const byte = paddedText.substr(i, 8);
                    buffer.writeUInt8(parseInt(byte, 2), i/8);
                }

                // Write header (frequency dictionary + padding info)
                const header = {
                    codes: this.codes,
                    padding: padding,
                    originalLength: text.length
                };
                const headerBuffer = Buffer.from(JSON.stringify(header));
                
                // Combine header and data
                const finalBuffer = Buffer.concat([
                    Buffer.from(headerBuffer.length + ','), // Header length prefix
                    headerBuffer,
                    buffer
                ]);

                fs.writeFileSync(outputPath, finalBuffer);
                resolve();
            } catch (error) {
                reject(error);
            }
        });
    }
}

module.exports = { HuffmanCompressor };